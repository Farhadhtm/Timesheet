package ir.timesheet

import java.time.LocalDate
import java.util.Locale

data class J(val y: Int, val m: Int, val d: Int) {
    fun key() = String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
}
data class Rec(val date: String, val s: Int, val e: Int, val d: String)

fun fa(s: String) = s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
fun hm(m: Int) = fa(String.format(Locale.US, "%02d:%02d", m / 60, m % 60))
fun dur(m: Int) = fa("${m / 60} ساعت و ${m % 60} دقیقه")
fun fdate(k: String) = Jal.wd(k) + " " + fa(k.replace('-', '/'))

object Jal {
    val MONTHS = arrayOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    private val DAYS = arrayOf("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")

    fun parse(k: String): J { val p = k.split("-"); return J(p[0].toInt(), p[1].toInt(), p[2].toInt()) }
    fun today(): J { val t = LocalDate.now(); return fromG(t.year, t.monthValue, t.dayOfMonth) }
    fun wd(k: String): String { val g = toG(parse(k)); return DAYS[LocalDate.of(g[0], g[1], g[2]).dayOfWeek.value - 1] }
    fun len(y: Int, m: Int): Int {
        if (m <= 6) return 31
        if (m <= 11) return 30
        val g = toG(J(y, 12, 30))
        return if (fromG(g[0], g[1], g[2]) == J(y, 12, 30)) 30 else 29
    }

    fun fromG(gy: Int, gm: Int, gd: Int): J {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053); days %= 12053
        jy += 4 * (days / 1461); days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
        val jd = 1 + (if (days < 186) days % 31 else (days - 186) % 30)
        return J(jy, jm, jd)
    }

    fun toG(j: J): IntArray {
        val jy = j.y + 1595
        var days = -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + j.d +
            (if (j.m < 7) (j.m - 1) * 31 else (j.m - 7) * 30 + 186)
        var gy = 400 * (days / 146097); days %= 146097
        if (days > 36524) { days--; gy += 100 * (days / 36524); days %= 36524; if (days >= 365) days++ }
        gy += 4 * (days / 1461); days %= 1461
        if (days > 365) { gy += (days - 1) / 365; days = (days - 1) % 365 }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val a = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > a[gm]) { gd -= a[gm]; gm++ }
        return intArrayOf(gy, gm, gd)
    }
}
