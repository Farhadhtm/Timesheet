package ir.timesheet

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private lateinit var db: Db
    private var my = 0
    private var mm = 0
    private var inMonth = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        db = Db(this)
        val t = Jal.today(); my = t.y; mm = t.m
        home()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (inMonth) home() else super.onBackPressed() }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun tv(s: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.BLACK) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }
    private fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
    private fun show(views: List<View>) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        views.forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col); layoutDirection = View.LAYOUT_DIRECTION_RTL })
    }
    private fun rowView(x: Rec) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8))
        addView(tv("${fdate(x.date)} | ${hm(x.s)} تا ${hm(x.e)} | ${dur(x.e - x.s)}", 15f, true))
        if (x.d.isNotBlank()) addView(tv(x.d, 14f, color = Color.DKGRAY))
        addView(View(context).apply { setBackgroundColor(0xFFDDDDDD.toInt()) }, ViewGroup.LayoutParams(-1, dp(1)))
        setOnClickListener { edit(x.date) }
    }
    private fun refreshScreen() { if (inMonth) month() else home() }

    // ---------- home ----------
    private fun home() {
        inMonth = false
        val t = Jal.today(); val k = t.key(); val r = db.get(k)
        val v = ArrayList<View>()
        v += tv("امروز: ${fdate(k)}", 20f, true)
        if (r != null) {
            v += tv("شروع: ${hm(r.s)}      پایان: ${hm(r.e)}")
            v += tv("مدت کار: ${dur(r.e - r.s)}", 18f, true)
            if (r.d.isNotBlank()) v += tv(r.d)
        } else v += tv("برای امروز چیزی ثبت نشده است.", color = Color.GRAY)
        v += btn(if (r == null) "ثبت امروز" else "ویرایش امروز") { edit(k) }.apply { textSize = 20f; setPadding(0, dp(18), 0, dp(18)) }
        v += btn("گزارش ماهانه") { my = t.y; mm = t.m; month() }
        v += tv("آخرین ثبت‌ها", 18f, true)
        db.recent(10).forEach { v += rowView(it) }
        show(v)
    }

    // ---------- monthly ----------
    private fun month() {
        inMonth = true
        val list = db.month(my, mm)
        val v = ArrayList<View>()
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        nav.addView(btn("ماه قبل") { if (mm == 1) { mm = 12; my-- } else mm--; month() })
        nav.addView(tv("${Jal.MONTHS[mm - 1]} ${fa(my.toString())}", 18f, true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(btn("ماه بعد") { if (mm == 12) { mm = 1; my++ } else mm++; month() })
        v += nav
        if (list.isEmpty()) v += tv("رکوردی برای این ماه ثبت نشده است.", color = Color.GRAY)
        list.forEach { v += rowView(it) }
        val total = list.sumOf { it.e - it.s }
        val avg = if (list.isEmpty()) 0 else total / list.size
        v += tv("تعداد روزهای ثبت‌شده: ${fa(list.size.toString())}", 16f, true)
        v += tv("مجموع ساعات کار: ${dur(total)}", 16f, true)
        v += tv("میانگین هر روز: ${dur(avg)}", 16f, true)
        v += btn("خروجی اکسل (xlsx)") { export(list) }
        v += btn("افزودن ثبت جدید") { edit(Jal.today().key()) }
        v += btn("بازگشت") { home() }
        show(v)
    }

    private fun export(list: List<Rec>) {
        if (list.isEmpty()) { toast("برای این ماه رکوردی وجود ندارد"); return }
        try {
            val dir = File(cacheDir, "exports").apply { mkdirs() }
            val f = File(dir, String.format(java.util.Locale.US, "timesheet-%04d-%02d.xlsx", my, mm))
            Xlsx.monthFile(f, "${Jal.MONTHS[mm - 1]} ${fa(my.toString())}", list)
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "ذخیره یا اشتراک‌گذاری"))
        } catch (e: Exception) { toast("خطا در ساخت فایل: ${e.message}") }
    }

    // ---------- editor ----------
    private fun edit(key: String) {
        var d = Jal.parse(key)
        var st = 8 * 60; var en = 16 * 60
        val existed = db.get(key) != null
        val desc = EditText(this).apply {
            hint = "شرح کار"; minLines = 3; gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val dateB = Button(this); val sB = Button(this); val eB = Button(this)
        val durT = tv("", 17f, true)
        fun refresh() {
            dateB.text = fdate(d.key()); sB.text = "شروع: ${hm(st)}"; eB.text = "پایان: ${hm(en)}"
            durT.text = if (en > st) "مدت کار: ${dur(en - st)}" else "ساعت پایان باید بعد از شروع باشد"
        }
        // switching to a date that already has a record loads it for editing (no duplicates possible)
        fun load() { db.get(d.key())?.let { st = it.s; en = it.e; desc.setText(it.d) } }
        load(); refresh()
        dateB.setOnClickListener { pickDate(d) { n -> d = n; load(); refresh() } }
        sB.setOnClickListener { TimePickerDialog(this, { _, h, m -> st = h * 60 + m; refresh() }, st / 60, st % 60, true).show() }
        eB.setOnClickListener { TimePickerDialog(this, { _, h, m -> en = h * 60 + m; refresh() }, en / 60, en % 60, true).show() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(dateB); addView(sB); addView(eB); addView(durT); addView(desc)
        }
        val b = AlertDialog.Builder(this).setTitle("ثبت زمان کار")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("ذخیره", null).setNegativeButton("انصراف", null)
        if (existed) b.setNeutralButton("حذف", null)
        val dlg = b.create(); dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (en <= st) { toast("ساعت پایان باید بعد از شروع باشد"); return@setOnClickListener }
            try {
                db.put(Rec(d.key(), st, en, desc.text.toString().trim()))
                dlg.dismiss(); refreshScreen()
            } catch (e: Exception) { toast("خطا در ذخیره: ${e.message}") }
        }
        if (existed) dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            AlertDialog.Builder(this).setMessage("این رکورد حذف شود؟")
                .setPositiveButton("حذف") { _, _ ->
                    try { db.delete(d.key()); dlg.dismiss(); refreshScreen() } catch (e: Exception) { toast("خطا: ${e.message}") }
                }.setNegativeButton("انصراف", null).show()
        }
    }

    private fun pickDate(cur: J, ok: (J) -> Unit) {
        fun np(vals: List<String>, idx: Int) = NumberPicker(this).apply {
            minValue = 0; maxValue = vals.size - 1; displayedValues = vals.toTypedArray()
            value = idx.coerceIn(0, vals.size - 1); wrapSelectorWheel = false
        }
        val y = np((1380..1500).map { fa("$it") }, cur.y - 1380)
        val m = np(Jal.MONTHS.toList(), cur.m - 1)
        val d = np((1..31).map { fa("$it") }, cur.d - 1)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(12), 0, 0)
            addView(d); addView(m); addView(y)   // RTL: year on the right
        }
        AlertDialog.Builder(this).setView(row)
            .setPositiveButton("تأیید") { _, _ ->
                val yy = 1380 + y.value; val mo = m.value + 1
                ok(J(yy, mo, (d.value + 1).coerceAtMost(Jal.len(yy, mo))))
            }.setNegativeButton("انصراف", null).show()
    }
}
