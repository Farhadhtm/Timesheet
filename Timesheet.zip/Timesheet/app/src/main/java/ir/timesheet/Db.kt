package ir.timesheet

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Locale

class Db(c: Context) : SQLiteOpenHelper(c, "timesheet.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE rec(date TEXT PRIMARY KEY, s INTEGER NOT NULL, e INTEGER NOT NULL, d TEXT NOT NULL)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun q(sql: String, vararg a: String): List<Rec> =
        readableDatabase.rawQuery(sql, a).use { c ->
            val l = ArrayList<Rec>()
            while (c.moveToNext()) l.add(Rec(c.getString(0), c.getInt(1), c.getInt(2), c.getString(3)))
            l
        }

    fun get(k: String) = q("SELECT date,s,e,d FROM rec WHERE date=?", k).firstOrNull()
    // date is the primary key: one record per day, saving the same date updates it
    fun put(r: Rec) { writableDatabase.execSQL("INSERT OR REPLACE INTO rec VALUES(?,?,?,?)", arrayOf<Any>(r.date, r.s, r.e, r.d)) }
    fun delete(k: String) { writableDatabase.delete("rec", "date=?", arrayOf(k)) }
    fun month(y: Int, m: Int) = q("SELECT date,s,e,d FROM rec WHERE date LIKE ? ORDER BY date", String.format(Locale.US, "%04d-%02d-%%", y, m))
    fun recent(n: Int) = q("SELECT date,s,e,d FROM rec ORDER BY date DESC LIMIT $n")
}
