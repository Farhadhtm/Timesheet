package ir.timesheet

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Xlsx {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private const val H = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"""
    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    fun monthFile(f: File, title: String, list: List<Rec>) {
        val rows = ArrayList<List<String>>()
        rows.add(listOf("تاریخ", "روز هفته", "شروع", "پایان", "مدت کار", "شرح کار"))
        list.forEach { rows.add(listOf(fa(it.date.replace('-', '/')), Jal.wd(it.date), hm(it.s), hm(it.e), hm(it.e - it.s), it.d)) }
        val total = list.sumOf { it.e - it.s }
        val avg = if (list.isEmpty()) 0 else total / list.size
        rows.add(emptyList())
        rows.add(listOf("تعداد روزهای کاری", fa(list.size.toString())))
        rows.add(listOf("مجموع ساعات کار", hm(total)))
        rows.add(listOf("میانگین ساعات روزانه", hm(avg)))
        val bold = setOf(0, rows.size - 3, rows.size - 2, rows.size - 1)
        write(f, title, rows, bold, listOf(22, 14, 10, 10, 12, 60))
    }

    private fun write(f: File, sheet: String, rows: List<List<String>>, bold: Set<Int>, widths: List<Int>) {
        ZipOutputStream(FileOutputStream(f)).use { z ->
            fun put(n: String, s: String) { z.putNextEntry(ZipEntry(n)); z.write(s.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", H + """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>""")
            put("_rels/.rels", H + """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="$REL/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml", H + """<workbook xmlns="$NS" xmlns:r="$REL"><sheets><sheet name="${esc(sheet)}" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            put("xl/_rels/workbook.xml.rels", H + """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="$REL/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="$REL/styles" Target="styles.xml"/></Relationships>""")
            val al = """<alignment horizontal="right" vertical="top" wrapText="1" readingOrder="2"/>"""
            put("xl/styles.xml", H + """<styleSheet xmlns="$NS"><fonts count="2"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><name val="Tahoma"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1">$al</xf><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">$al</xf></cellXfs></styleSheet>""")
            val sb = StringBuilder()
            sb.append(H).append("""<worksheet xmlns="$NS"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews><cols>""")
            widths.forEachIndexed { i, w -> sb.append("""<col min="${i + 1}" max="${i + 1}" width="$w" customWidth="1"/>""") }
            sb.append("</cols><sheetData>")
            rows.forEachIndexed { r, cells ->
                sb.append("""<row r="${r + 1}">""")
                cells.forEachIndexed { c, v ->
                    sb.append("""<c r="${'A' + c}${r + 1}" t="inlineStr" s="${if (r in bold) 1 else 0}"><is><t xml:space="preserve">${esc(v)}</t></is></c>""")
                }
                sb.append("</row>")
            }
            sb.append("</sheetData></worksheet>")
            put("xl/worksheets/sheet1.xml", sb.toString())
        }
    }
}
