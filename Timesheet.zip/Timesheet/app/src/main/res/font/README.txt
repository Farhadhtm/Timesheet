فایل Vazirmatn-Regular.ttf را با نام vazirmatn.ttf اینجا قرار دهید.
